import type { SettingStore } from "@/store/setting";

export const DEFAULT_PRESET: Partial<SettingStore> = {
  provider: "openai",
  mode: "proxy",
  apiKey: "",
  apiProxy: "https://api.openai.com/v1",
  thinkingModel: "gpt-4",
  networkingModel: "gpt-3.5-turbo",
  openAIApiKey: "",
  openAIApiProxy: "https://api.openai.com/v1",
  openAIThinkingModel: "gpt-4",
  openAINetworkingModel: "gpt-3.5-turbo",
  enableSearch: "1",
  searchProvider: "bocha",
  parallelSearch: 3,
  searchMaxResult: 5,
  language: "zh-CN",
  theme: "system",
  debug: "disable",
  accessPassword: "8888"
}; 