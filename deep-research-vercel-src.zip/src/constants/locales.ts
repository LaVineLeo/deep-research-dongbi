export default {
  "zh-CN": "简体中文",
  "en-US": "English",
} as const;
