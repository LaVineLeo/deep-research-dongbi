import { BOCHA_BASE_URL } from "@/constants/urls";export async function testBochaApi(apiKey: string, apiProxy?: string) {
  try {    const baseUrl = apiProxy || BOCHA_BASE_URL;    const response = await fetch(baseUrl, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        agentId: "bocha-scholar-agent",
        query: "Foundation models",
        searchType: "neural",
        stream: false
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return { success: true, data };
  } catch (error) {
    console.error("测试 Bocha API 失败:", error);
    return { success: false, error: error instanceof Error ? error.message : "未知错误" };
  }
} 